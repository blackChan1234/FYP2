package Restaurant;

public class opening {

	private boolean open;

	public boolean getOpen() {
		return this.open;
	}

	/**
	 * 
	 * @param open
	 */
	public void setOpen(boolean open) {
		this.open = open;
	}
	public opening(boolean open) {
		this.open = open;
	}

}