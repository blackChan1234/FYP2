package Restaurant;

public class image {
    private String imgPath="demo.png";
    
    public image(String imgPath) {
        this.imgPath = imgPath;
    }
    public image(){

    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }
    
    public String getImgPath() {
        return imgPath;
    }
}
